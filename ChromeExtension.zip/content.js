
var port = chrome.runtime.connect();
var id="";

window.addEventListener("message", function(event) {
  // We only accept messages from ourselves
  if (event.source != window)
    console.log("Didn'get the data");

  if (event.data.type && (event.data.type == "FROM_PAGE")) {
    id = event.data.text[0];
    url = event.data.text;

    chrome.storage.local.set({url: url});

    chrome.runtime.sendMessage({'message': 'send_id' , 'data': id},function(response){
        if(response.response = "done"){
            console.log(response.response);
        }
    });

    port.postMessage(event.data.text);
  }
}, false);

// if(order.id!=""){
//     chrome.runtime.sendMessage({'message': 'send_id' , 'data': id},function(response){
//         if(response.answer = "done"){
//             console.log(response.answer);
//         }
//     });
// }else{
//     console.log("Id is empty");
// }