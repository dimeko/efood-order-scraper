var id;

chrome.extension.onMessage.addListener(function(request, sender, sendResponse){
    if(request.message=="send_id"){
        id=request.data;
        sendResponse = "done";
        console.log(id);
    }
    else if(request.message=='send'){
    var xhr = new XMLHttpRequest();
    var  url = "http://SampleProject-env.eba-d26fhkqt.us-east-2.elasticbeanstalk.com/api/order";
    
    xhr.open("POST", url, true); 
    xhr.setRequestHeader("Content-Type", "application/json"); 

    var sender = request.data;
    sender.id = id

    const sendd = JSON.stringify(sender);
    console.log(sendd);
    xhr.send(sendd); 

    sendResponse({answer: "done"});

    chrome.tabs.update({url: "http://SampleProject-env.eba-d26fhkqt.us-east-2.elasticbeanstalk.com/order"});
    }else{
        console.log("Not now");
    }

 });
